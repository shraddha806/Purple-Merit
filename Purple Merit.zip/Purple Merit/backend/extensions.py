from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager

# simple in-memory token blacklist for logout (demo only)
jwt_blacklist = set()

db = SQLAlchemy()
migrate = Migrate()
bcrypt = Bcrypt()
jwt = JWTManager()

@jwt.token_in_blocklist_loader
def check_if_token_revoked(jwt_header, jwt_payload):
    jti = jwt_payload.get("jti")
    return jti in jwt_blacklist

# Clear JSON error responses and logging for common JWT errors
@jwt.unauthorized_loader
def handle_missing_token(err_msg):
    # missing Authorization header
    print('JWT unauthorized:', err_msg)
    return ({"error": {"message": err_msg}}, 401)

@jwt.invalid_token_loader
def handle_invalid_token(err_msg):
    print('JWT invalid token:', err_msg)
    return ({"error": {"message": err_msg}}, 422)

@jwt.expired_token_loader
def handle_expired_token(jwt_header, jwt_payload):
    msg = "Token has expired"
    print('JWT expired')
    return ({"error": {"message": msg}}, 401)

@jwt.revoked_token_loader
def handle_revoked_token(jwt_header, jwt_payload):
    msg = "Token has been revoked"
    print('JWT revoked')
    return ({"error": {"message": msg}}, 401)
