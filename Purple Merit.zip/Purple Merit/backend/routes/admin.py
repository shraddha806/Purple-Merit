from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import User
from extensions import db

admin_bp = Blueprint("admin", __name__)


def admin_required(fn):
    def wrapper(*args, **kwargs):
        uid = get_jwt_identity()
        user = User.query.get(uid)
        if not user or user.role != "admin":
            return jsonify({"error": {"message": "Admin privilege required"}}), 403
        return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


@admin_bp.route("/users", methods=["GET"]) 
@jwt_required()
@admin_required
def list_users():
    try:
        page = int(request.args.get("page", 1))
    except ValueError:
        page = 1
    per_page = 10
    q = User.query.order_by(User.created_at.desc())
    pag = q.paginate(page=page, per_page=per_page, error_out=False)
    items = [u.to_dict() for u in pag.items]
    return jsonify({"users": items, "page": page, "total": pag.total, "pages": pag.pages}), 200


@admin_bp.route("/users/<int:user_id>/activate", methods=["POST"]) 
@jwt_required()
@admin_required
def activate_user(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": {"message": "User not found"}}), 404
    user.is_active = True
    db.session.commit()
    return jsonify({"message": "User activated", "user": user.to_dict()}), 200


@admin_bp.route("/users/<int:user_id>/deactivate", methods=["POST"]) 
@jwt_required()
@admin_required
def deactivate_user(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": {"message": "User not found"}}), 404
    user.is_active = False
    db.session.commit()
    return jsonify({"message": "User deactivated", "user": user.to_dict()}), 200
