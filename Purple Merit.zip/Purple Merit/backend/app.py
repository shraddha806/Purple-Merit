from flask import Flask, jsonify, render_template, request
from config import Config
from extensions import db, migrate, bcrypt, jwt
from routes.auth import auth_bp
from routes.admin import admin_bp
from routes.user import user_bp
from routes.tasks import tasks_bp


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)

    db.init_app(app)
    migrate.init_app(app, db)
    bcrypt.init_app(app)
    jwt.init_app(app)

    # In development mode create all tables automatically to avoid missing-table errors
    if app.debug:
        # ensure models are imported so SQLAlchemy metadata is populated
        try:
            import models  # noqa: F401
        except Exception:
            pass
        with app.app_context():
            db.create_all()

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(admin_bp, url_prefix="/api/admin")
    app.register_blueprint(user_bp, url_prefix="/api/user")
    app.register_blueprint(tasks_bp, url_prefix="/api/tasks")

    @app.route("/", methods=["GET"])
    def index():
        accept = request.headers.get("Accept", "")
        if "text/html" in accept:
            return render_template("index.html")
        return jsonify({
            "message": "API is running",
            "routes": ["/api/auth", "/api/admin", "/api/user"]
        }), 200

    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "ok"}), 200

    # Development-only helper to create a demo admin user for the frontend demo
    @app.route("/seed-admin", methods=["GET"]) 
    def seed_admin():
        from models import User
        # Only allow in debug mode
        if not app.debug:
            return jsonify({"error": {"message": "Not allowed"}}), 403
        # ensure tables exist before querying
        try:
            db.create_all()
        except Exception:
            pass
        admin_email = "admin@example.com"
        admin = User.query.filter_by(email=admin_email).first()
        if admin:
            return jsonify({"message": "Admin already exists", "user": admin.to_dict()}), 200
        admin = User(email=admin_email, full_name="Admin User", role="admin")
        admin.set_password("AdminPass1!")
        admin.is_active = True
        db.session.add(admin)
        db.session.commit()
        return jsonify({"message": "Admin created", "user": admin.to_dict()}), 201

    # Frontend routes
    @app.route('/login')
    def login_page():
        return render_template('login.html')

    @app.route('/signup')
    def signup_page():
        return render_template('signup.html')

    @app.route('/dashboard')
    def dashboard_page():
        return render_template('dashboard.html')

    @app.route('/admin')
    def admin_page():
        return render_template('admin.html')

    @app.route('/profile')
    def profile_page():
        return render_template('profile.html')
    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": {"message": "Not Found"}}), 404

    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({"error": {"message": "Bad Request"}}), 400

    return app


if __name__ == "__main__":
    app = create_app()
    # Ensure tables exist when running the development server directly
    with app.app_context():
        try:
            db.create_all()
        except Exception:
            pass
    app.run(host="0.0.0.0", port=5000, debug=True)
