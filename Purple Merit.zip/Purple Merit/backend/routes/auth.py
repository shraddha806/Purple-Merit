import re
from datetime import datetime
from flask import Blueprint, request, jsonify
from models import User
from extensions import db, jwt_blacklist
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity, get_jwt

auth_bp = Blueprint("auth", __name__)

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_password_strength(pw: str) -> bool:
    if len(pw) < 8:
        return False
    if not re.search(r"[A-Z]", pw):
        return False
    if not re.search(r"[0-9]", pw):
        return False
    if not re.search(r"[!@#$%^&*(),.?\"{}|<>]", pw):
        return False
    return True


@auth_bp.route("/signup", methods=["POST"]) 
def signup():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    full_name = data.get("full_name", "").strip()

    if not email or not password or not full_name:
        return jsonify({"error": {"message": "email, password and full_name are required"}}), 400

    if not EMAIL_REGEX.match(email):
        return jsonify({"error": {"message": "Invalid email format"}}), 400

    if not validate_password_strength(password):
        return jsonify({"error": {"message": "Password too weak"}}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"error": {"message": "Email already registered"}}), 400

    user = User(email=email, full_name=full_name)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    access_token = create_access_token(identity=user.id)
    return jsonify({"access_token": access_token, "user": user.to_dict()}), 201


@auth_bp.route("/signup", methods=["GET"])
def signup_info():
    # Friendly message for browser navigation to the API route
    return jsonify({"error": {"message": "This endpoint accepts POST requests to create an account. Use the frontend at /signup or POST JSON to /api/auth/signup."}}), 405


@auth_bp.route("/login", methods=["POST"]) 
def login():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"error": {"message": "email and password are required"}}), 400

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return jsonify({"error": {"message": "Invalid credentials"}}), 401

    if not user.is_active:
        return jsonify({"error": {"message": "Account is inactive"}}), 403

    user.last_login = datetime.utcnow()
    db.session.commit()
    access_token = create_access_token(identity=user.id)
    return jsonify({"access_token": access_token, "user": user.to_dict()}), 200


@auth_bp.route("/login", methods=["GET"])
def login_info():
    return jsonify({"error": {"message": "This endpoint accepts POST requests to login. Use the frontend at /login or POST JSON to /api/auth/login."}}), 405


@auth_bp.route("/logout", methods=["POST"]) 
@jwt_required()
def logout():
    jti = get_jwt().get("jti")
    jwt_blacklist.add(jti)
    return jsonify({"message": "Successfully logged out"}), 200


@auth_bp.route("/me", methods=["GET"]) 
@jwt_required()
def me():
    uid = get_jwt_identity()
    user = User.query.get(uid)
    if not user:
        return jsonify({"error": {"message": "User not found"}}), 404
    return jsonify({"user": user.to_dict()}), 200
