from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import Task, User
from extensions import db
from datetime import datetime
import re

tasks_bp = Blueprint('tasks', __name__)

STOPWORDS = set([
    'the','and','is','in','at','of','a','to','for','on','with','by','an','be','this','that','it','from','as'
])


def simple_ai_simulate(title, description):
    text = ' '.join([title or '', description or '']).strip()
    # summary: first sentence or first 120 chars
    summary = ''
    m = re.search(r'(.*?[\.\!\?])\s', text)
    if m:
        summary = m.group(1).strip()
    else:
        summary = text[:120].strip()
    # tags: pick top token-like words
    tokens = re.findall(r"\w{3,}", text.lower())
    freq = {}
    for t in tokens:
        if t in STOPWORDS: continue
        freq[t] = freq.get(t, 0) + 1
    tags = sorted(freq.keys(), key=lambda k: -freq[k])[:5]
    return summary or None, tags


@tasks_bp.route('', methods=['GET'])
@tasks_bp.route('/', methods=['GET'])
@jwt_required()
def list_tasks():
    uid = get_jwt_identity()
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        return jsonify({"error": {"message": "Invalid token subject"}}), 401

    q = (request.args.get('q') or '').strip()
    tag = (request.args.get('tag') or '').strip().lower()
    status = (request.args.get('status') or '').strip().lower()

    query = Task.query.filter_by(user_id=uid)
    if q:
        like = f"%{q}%"
        query = query.filter((Task.title.ilike(like)) | (Task.description.ilike(like)))
    if tag:
        query = query.filter(Task.tags.ilike(f"%{tag}%"))
    if status:
        query = query.filter_by(status=status)

    tasks = query.order_by(Task.created_at.desc()).all()
    return jsonify({ 'tasks': [t.to_dict() for t in tasks] }), 200


@tasks_bp.route('/<int:task_id>', methods=['GET'])
@jwt_required()
def get_task(task_id):
    uid = get_jwt_identity()
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        return jsonify({"error": {"message": "Invalid token subject"}}), 401
    t = Task.query.get(task_id)
    if not t or t.user_id != uid:
        return jsonify({"error": {"message": "Not found"}}), 404
    return jsonify({ 'task': t.to_dict() }), 200


@tasks_bp.route('', methods=['POST'])
@tasks_bp.route('/', methods=['POST'])
@jwt_required()
def create_task():
    uid = get_jwt_identity()
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        return jsonify({"error": {"message": "Invalid token subject"}}), 401

    # Ensure tables exist (helps when model was recently added and DB lacks table)
    try:
        db.create_all()
    except Exception:
        pass

    # Robust JSON parsing with clear 422 on malformed JSON and logging for debugging
    try:
        data = request.get_json()
        if data is None:
            data = {}
    except Exception as e:
        body_text = request.get_data(as_text=True)
        print('Create task: invalid JSON:', e)
        print('Headers:', dict(request.headers))
        print('Body:', body_text)
        return jsonify({"error": {"message": f"Invalid JSON: {str(e)}"}}), 422

    title = (data.get('title') or '').strip()
    description = (data.get('description') or '').strip()
    summary = data.get('summary')
    tags = data.get('tags')
    status = data.get('status') or 'todo'
    due_date = data.get('due_date')

    if not title:
        return jsonify({"error": {"message": "Title required"}}), 400

    # allow simulation
    if not summary or not tags:
        s, t = simple_ai_simulate(title, description)
        if not summary:
            summary = s
        if not tags:
            tags = t

    tags_str = ','.join([x.strip() for x in (tags or [])]) if isinstance(tags, list) else (tags or '')

    td = None
    if due_date:
        try:
            td = datetime.fromisoformat(due_date)
        except Exception:
            return jsonify({"error": {"message": "Invalid due_date"}}), 400

    task = Task(title=title, description=description, summary=summary, tags=tags_str, status=status, due_date=td, user_id=uid)
    try:
        db.session.add(task)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print('Create task: DB commit error:', e)
        return jsonify({"error": {"message": "Server error creating task"}}), 500

    return jsonify({ 'task': task.to_dict() }), 201


@tasks_bp.route('/<int:task_id>', methods=['PUT'])
@jwt_required()
def update_task(task_id):
    uid = get_jwt_identity()
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        return jsonify({"error": {"message": "Invalid token subject"}}), 401
    t = Task.query.get(task_id)
    if not t or t.user_id != uid:
        return jsonify({"error": {"message": "Not found"}}), 404

    data = request.get_json() or {}
    title = data.get('title')
    description = data.get('description')
    summary = data.get('summary')
    tags = data.get('tags')
    status = data.get('status')
    due_date = data.get('due_date')

    if title is not None:
        t.title = title.strip()
    if description is not None:
        t.description = description.strip()
    if status is not None:
        t.status = status

    if tags is not None:
        t.tags = ','.join([x.strip() for x in tags]) if isinstance(tags, list) else (tags or '')

    if summary is not None:
        t.summary = summary
    else:
        # if user changed title/description but left summary empty, regenerate
        if (title or description) and not t.summary:
            s, _ = simple_ai_simulate(t.title, t.description)
            t.summary = s

    if due_date is not None:
        if due_date == '':
            t.due_date = None
        else:
            try:
                t.due_date = datetime.fromisoformat(due_date)
            except Exception:
                return jsonify({"error": {"message": "Invalid due_date"}}), 400

    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({"error": {"message": "Server error updating task"}}), 500
    return jsonify({ 'task': t.to_dict() }), 200


@tasks_bp.route('/<int:task_id>', methods=['DELETE'])
@jwt_required()
def delete_task(task_id):
    uid = get_jwt_identity()
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        return jsonify({"error": {"message": "Invalid token subject"}}), 401
    t = Task.query.get(task_id)
    if not t or t.user_id != uid:
        return jsonify({"error": {"message": "Not found"}}), 404
    db.session.delete(t)
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({"error": {"message": "Server error deleting task"}}), 500
    return jsonify({ 'message': 'Deleted' }), 200


@tasks_bp.route('/ai-simulate', methods=['POST'])
@jwt_required()
def ai_simulate():
    data = request.get_json() or {}
    title = (data.get('title') or '').strip()
    description = (data.get('description') or '').strip()
    s, tags = simple_ai_simulate(title, description)
    return jsonify({ 'summary': s, 'tags': tags }), 200
