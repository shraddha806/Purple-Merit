from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import User
from extensions import db
import re

user_bp = Blueprint("user", __name__)

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@user_bp.route("/profile", methods=["GET"]) 
@jwt_required()
def profile():
    uid = get_jwt_identity()
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        return jsonify({"error": {"message": "Invalid token subject"}}), 401
    user = User.query.get(uid)
    if not user:
        return jsonify({"error": {"message": "User not found"}}), 404
    return jsonify({"user": user.to_dict()}), 200


@user_bp.route("/profile", methods=["PUT"]) 
@jwt_required()
def update_profile():
    uid = get_jwt_identity()
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        return jsonify({"error": {"message": "Invalid token subject"}}), 401
    user = User.query.get(uid)
    if not user:
        return jsonify({"error": {"message": "User not found"}}), 404

    data = request.get_json() or {}
    full_name = data.get("full_name", "").strip()
    email = data.get("email", "").strip().lower()

    if email and not EMAIL_REGEX.match(email):
        return jsonify({"error": {"message": "Invalid email format"}}), 400

    if email and email != user.email and User.query.filter_by(email=email).first():
        return jsonify({"error": {"message": "Email already in use"}}), 400

    if full_name:
        user.full_name = full_name
    if email:
        user.email = email

    db.session.commit()
    return jsonify({"user": user.to_dict(), "message": "Profile updated"}), 200


@user_bp.route("/change-password", methods=["POST"]) 
@jwt_required()
def change_password():
    uid = get_jwt_identity()
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        return jsonify({"error": {"message": "Invalid token subject"}}), 401
    user = User.query.get(uid)
    if not user:
        return jsonify({"error": {"message": "User not found"}}), 404

    data = request.get_json() or {}
    old = data.get("old_password", "")
    new = data.get("new_password", "")

    if not old or not new:
        return jsonify({"error": {"message": "old_password and new_password required"}}), 400

    if not user.check_password(old):
        return jsonify({"error": {"message": "Current password incorrect"}}), 401

    if len(new) < 8:
        return jsonify({"error": {"message": "New password too short"}}), 400

    user.set_password(new)
    db.session.commit()
    return jsonify({"message": "Password changed"}), 200
