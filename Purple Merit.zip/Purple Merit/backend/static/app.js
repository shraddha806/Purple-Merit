/* Simple frontend helper for demo app */
async function apiFetch(path, opts = {}, auth = false, method = 'GET'){
  const headers = opts.headers || {};
  headers['Content-Type'] = 'application/json';
  if (auth){ const t = localStorage.getItem('token'); if (t) headers['Authorization'] = 'Bearer '+t }
  const res = await fetch(path, { method, headers, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const text = await res.text();
  try{ return JSON.parse(text || '{}') }catch(e){ return { raw: text } }
}

function apiGet(path, auth=false){ return apiFetch(path, {}, auth, 'GET') }
function apiPost(path, body={}, auth=false){ return apiFetch(path, { body }, auth, 'POST') }
function apiPut(path, body={}, auth=false){ return apiFetch(path, { body }, auth, 'PUT') }

function showToast(msg, type='error'){
  const el = document.getElementById('message') || document.createElement('div');
  el.className = 'toast '+(type==='success'? 'ok':'');
  el.textContent = msg;
  if (!document.getElementById('message')) document.body.appendChild(el);
  setTimeout(()=>el.textContent='', 4000);
}

function getUser(){
  try{ return JSON.parse(localStorage.getItem('user')||'null') }catch(e){ return null }
}

// helper to auto-seed admin if requested (dev only)
async function ensureAdmin(){
  if (location.search.indexOf('seed=1')!==-1){
    await apiGet('/seed-admin', false);
    showToast('Admin seeded (dev)', 'success');
  }
}

// run on load
ensureAdmin();
