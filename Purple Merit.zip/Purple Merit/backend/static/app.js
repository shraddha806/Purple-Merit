/* Simple frontend helper for demo app */
async function apiFetch(path, opts = {}, auth = false, method = 'GET'){
  const headers = opts.headers || {};
  // Only set content-type when there is a body (avoid confusing servers with empty JSON types on GET)
  if (opts.body) headers['Content-Type'] = 'application/json';
  if (auth){ const t = localStorage.getItem('token'); if (t && t !== 'undefined' && t !== 'null') headers['Authorization'] = 'Bearer '+t }
  const res = await fetch(path, { method, headers, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const text = await res.text();
  let json = null
  try{ json = JSON.parse(text || '{}') }catch(e){ json = null }
  if (!res.ok){
    // Return error info consistently (prefers message from JSON error, falls back to raw text)
    const msg = (json && json.error && json.error.message) ? json.error.message : (text || 'Server error')
    return Object.assign(json || {}, { error: { message: msg }, status: res.status })
  }
  return json || {}
}

function apiGet(path, auth=false){ return apiFetch(path, {}, auth, 'GET') }
function apiPost(path, body={}, auth=false){ return apiFetch(path, { body }, auth, 'POST') }
function apiPut(path, body={}, auth=false){ return apiFetch(path, { body }, auth, 'PUT') }

function showToast(msg, type='error'){
  const el = document.getElementById('message') || document.createElement('div');
  el.className = 'toast '+(type==='success'? 'ok':'');
  el.textContent = msg;
  if (!document.getElementById('message')) document.body.appendChild(el);
  setTimeout(()=>el.textContent='', 4000);
}

function getUser(){
  try{ return JSON.parse(localStorage.getItem('user')||'null') }catch(e){ return null }
}

// helper to auto-seed admin if requested (dev only)
async function ensureAdmin(){
  if (location.search.indexOf('seed=1')!==-1){
    await apiGet('/seed-admin', false);
    showToast('Admin seeded (dev)', 'success');
  }
}

// run on load
ensureAdmin();

// Task UI and API helpers
let editingTaskId = null

async function loadTasks(){
  const q = document.getElementById('taskSearch')?.value || ''
  const status = document.getElementById('statusFilter')?.value || ''
  const params = new URLSearchParams()
  if (q) params.set('q', q)
  if (status) params.set('status', status)
  const res = await apiGet('/api/tasks?'+params.toString(), true)
  if (res.error) { showToast(res.error.message || 'Error loading tasks'); return }
  const list = document.getElementById('tasksList')
  list.innerHTML = ''
  const tasks = (res.tasks||[])
  if (!tasks.length){
    const el = document.createElement('div')
    el.className = 'muted'
    el.textContent = 'No tasks found'
    list.appendChild(el)
    return
  }
  tasks.forEach(t => list.appendChild(renderTaskItem(t)))
}

function renderTaskItem(t){
  const li = document.createElement('li')
  li.className = 'task-item'
  li.innerHTML = `<div class="task-head"><strong>${escapeHtml(t.title)}</strong>
      <div class="row" style="gap:8px;align-items:center">
        <span class="muted">${t.due_date? 'Due: '+t.due_date.split('T')[0]:''}</span>
        <select class="status-select" data-id="${t.id}">
          <option value="todo" ${t.status==='todo' ? 'selected':''}>To do</option>
          <option value="in-progress" ${t.status==='in-progress' ? 'selected':''}>In progress</option>
          <option value="done" ${t.status==='done' ? 'selected':''}>Done</option>
        </select>
      </div>
    </div>
    <div class="task-body">${escapeHtml(t.summary || t.description || '')}</div>
    <div class="task-meta">Tags: ${(t.tags||[]).join(', ')}</div>
    <div class="task-actions"> <button class="secondary" data-id="${t.id}" data-action="edit">Edit</button> <button class="secondary" data-id="${t.id}" data-action="delete">Delete</button></div>`

  li.querySelector('[data-action="edit"]').addEventListener('click', ()=>openTaskForm(t))
  li.querySelector('[data-action="delete"]').addEventListener('click', ()=>deleteTask(t.id))
  // status change handler
  li.querySelector('.status-select').addEventListener('change', async (e)=>{
    const newStatus = e.target.value
    try{
      const res = await apiPut('/api/tasks/'+t.id, { status: newStatus }, true)
      if (res.error){ showToast(res.error.message || 'Error updating status');
      } else { showToast('Status updated', 'success'); loadTasks() }
    }catch(err){ showToast('Network error') }
  })
  return li
}

function escapeHtml(s){ return (s||'').replace(/[&<">']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[c]) }

function openTaskForm(task){
  editingTaskId = task?.id || null
  document.getElementById('taskForm').style.display = 'block'
  document.getElementById('taskFormTitle').textContent = task? 'Edit Task':'New Task'
  document.getElementById('taskTitle').value = task?.title || ''
  document.getElementById('taskDescription').value = task?.description || ''
  document.getElementById('taskSummary').value = task?.summary || ''
  document.getElementById('taskTags').value = (task?.tags||[]).join(', ')
  // datetime-local expects YYYY-MM-DDTHH:MM (slice off seconds if present)
  document.getElementById('taskDue').value = task?.due_date ? task.due_date.slice(0,16) : ''
  document.getElementById('taskStatus').value = task?.status || 'todo'
}

function closeTaskForm(){
  editingTaskId = null
  document.getElementById('taskForm').style.display = 'none'
}

async function saveTask(){
  const title = document.getElementById('taskTitle').value.trim()
  const description = document.getElementById('taskDescription').value.trim()
  const summary = document.getElementById('taskSummary').value.trim()
  const tags = document.getElementById('taskTags').value.split(',').map(s=>s.trim()).filter(Boolean)
  const due = document.getElementById('taskDue').value.trim()
  const status = document.getElementById('taskStatus').value
  if (!title){ showToast('Title required'); return }
  const body = { title, description, summary: summary || undefined, tags, due_date: due || undefined, status }
  if (editingTaskId){
    const res = await apiPut('/api/tasks/' + editingTaskId, body, true)
    if (res.error) { showToast(res.error.message || 'Error saving'); return }
    showToast('Task updated', 'success')
  } else {
    const res = await apiPost('/api/tasks', body, true)
    if (res.error) { showToast(res.error.message || 'Error creating'); return }
    showToast('Task created', 'success')
  }
  closeTaskForm()
  await loadTasks()
}

async function deleteTask(id){
  if (!confirm('Delete task?')) return
  const res = await fetch('/api/tasks/'+id, { method: 'DELETE', headers: { 'Content-Type':'application/json', 'Authorization': 'Bearer '+localStorage.getItem('token') }})
  const text = await res.text()
  let data = {}
  try{ data = JSON.parse(text || '{}') }catch(e){ data = { error: { message: text } } }
  if (!res.ok){ showToast(data.error?.message || 'Error deleting') ; return }
  showToast('Deleted', 'success')
  await loadTasks()
}

async function aiSuggest(){
  const title = document.getElementById('taskTitle').value.trim()
  const description = document.getElementById('taskDescription').value.trim()
  const res = await apiPost('/api/tasks/ai-simulate', { title, description }, true)
  if (res.error) { showToast(res.error.message || 'AI error'); return }
  document.getElementById('taskSummary').value = res.summary || ''
  document.getElementById('taskTags').value = (res.tags||[]).join(', ')
  showToast('AI suggestions applied', 'success')
}

// bind UI events
document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('newTaskBtn')?.addEventListener('click', ()=>openTaskForm())
  document.getElementById('cancelTaskBtn')?.addEventListener('click', ()=>closeTaskForm())
  document.getElementById('saveTaskBtn')?.addEventListener('click', ()=>saveTask())
  document.getElementById('aiSimulateBtn')?.addEventListener('click', ()=>aiSuggest())
  // debounce the search input so we don't spam the API
  let searchTimer = null
  document.getElementById('taskSearch')?.addEventListener('input', ()=>{
    clearTimeout(searchTimer)
    searchTimer = setTimeout(()=>loadTasks(), 300)
  })
  document.getElementById('statusFilter')?.addEventListener('change', ()=>loadTasks())
  loadTasks()
})
