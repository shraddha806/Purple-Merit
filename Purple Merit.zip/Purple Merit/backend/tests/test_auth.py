import pytest
from app import create_app
from extensions import db
from models import User
import json

class TestConfig:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    TESTING = True
    JWT_SECRET_KEY = 'test-secret'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


@pytest.fixture
def client():
    app = create_app(config_object=TestConfig)
    with app.app_context():
        db.init_app(app)
        db.create_all()
        yield app.test_client()
        db.session.remove()
        db.drop_all()


def signup(client, email, password, full_name="Test User"):
    return client.post('/api/auth/signup', json={"email": email, "password": password, "full_name": full_name})


def login(client, email, password):
    return client.post('/api/auth/login', json={"email": email, "password": password})


def test_password_hashing():
    u = User(email='a@b.com', full_name='A')
    u.set_password('Password1!')
    assert u.password_hash != 'Password1!'
    assert u.check_password('Password1!')


def test_signup_validation(client):
    # weak password
    r = signup(client, 'user@example.com', 'weak')
    assert r.status_code == 400
    # invalid email
    r = signup(client, 'not-an-email', 'StrongPass1!')
    assert r.status_code == 400


def test_signup_and_login_flow(client):
    r = signup(client, 'user1@example.com', 'StrongPass1!')
    assert r.status_code == 201
    data = r.get_json()
    assert 'access_token' in data

    r2 = login(client, 'user1@example.com', 'StrongPass1!')
    assert r2.status_code == 200
    data2 = r2.get_json()
    assert 'access_token' in data2


def test_protected_route_requires_auth(client):
    r = client.get('/api/user/profile')
    assert r.status_code == 401 or r.status_code == 422


def test_admin_only_access(client):
    # create normal user
    signup(client, 'u2@example.com', 'StrongPass1!')
    rv = login(client, 'u2@example.com', 'StrongPass1!')
    token = rv.get_json()['access_token']

    # attempt admin endpoint
    r = client.get('/api/admin/users', headers={"Authorization": f"Bearer {token}"})
    assert r.status_code in (403, 401)
